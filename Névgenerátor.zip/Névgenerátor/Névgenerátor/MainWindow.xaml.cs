﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using System.Windows.Input;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;

namespace Névgenerátor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private ObservableCollection<string> csaladNevek = new(), utoNevek = new(), generaltNevek = new();
        

        private void btnBetoltCsaladnevek_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                foreach (var nev in File.ReadLines(ofd.FileName).ToList())
                {
                    csaladNevek.Add(nev);
                }
                lbCsaladNevek.ItemsSource = csaladNevek;
            }
        }
        private void btnBetoltUtonevek_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                foreach (var nev in File.ReadLines(ofd.FileName).ToList())
                {
                    utoNevek.Add(nev);
                }
                lbUtoNevek.ItemsSource = utoNevek;
            }
        }


        private void btnNevekGeneral_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new();
            for(int i = 0; i < slLetrehozandoNevekSzama.Value; i++)
            {
                if(rbEgy.IsChecked==true)
                    generaltNevek.Add($"{GeneralNev(csaladNevek)} {GeneralNev(utoNevek)}");
                else if(rbKetto.IsChecked==true)
                    generaltNevek.Add($"{GeneralNev(csaladNevek)} {GeneralNev(utoNevek)} {GeneralNev(utoNevek)}");
                else
                    return;
            }
            lbGeneraltNevek.ItemsSource = generaltNevek;

            string GeneralNev(ObservableCollection<string> lista)
            {
                int index = rnd.Next(lista.Count);
                string nev = lista[index];
                lista.Remove(nev);
                return nev;
            }
        }
        private void btnNevekTorol_Click(object sender, RoutedEventArgs e)
        {
            string[] nev;
            foreach(string _nev in generaltNevek)
            {
                nev = _nev.Split(' ');
                for(byte index = 0; index < nev.Length; index++)
                {
                    if(index<1)
                        csaladNevek.Add(nev[index]);
                    else
                        utoNevek.Add(nev[index]);
                }
            }
            generaltNevek.Clear();
        }
        private void btnNevekRendez_Click(object sender, RoutedEventArgs e) => lbGeneraltNevek.Items.SortDescriptions.Add(new SortDescription("", ListSortDirection.Ascending));

        private void btnNevekMentes_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new()
            {
                AddExtension = true,
                DefaultExt = "txt",
                Filter = "Szöveges fájl (*.txt)|*txt|CSV fájl (*.csv)|*.csv|Összes fájl (*.*)|*.*",
                Title = "Adja meg a névsor nevét!"
            };

            if (sfd.ShowDialog() == true)
            {
                try
                {
                    if(Path.GetExtension(sfd.FileName).ToLower()==".csv")
                    {
                        string[] nevek = new string[generaltNevek.Count];
                        for(int i = 0; i < generaltNevek.Count; i++)
                            nevek[i] = String.Join(';', generaltNevek[i].Split(' '));
                        File.WriteAllLines(sfd.FileName, nevek);
                    }
                    else
                        File.WriteAllLines(sfd.FileName, generaltNevek);
                }
                catch
                {
                    return;
                }
            }
        }

        private void lbGeneraltNevek_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ListBox? lBox = sender as ListBox;
            if (lBox != null)
            {
                try
                {
                    string[] nev = Convert.ToString(lBox.SelectedItem).Split();
                    csaladNevek.Add(nev[0]);
                    utoNevek.Add(nev[1]);
                    if(nev.Length > 2)
                        utoNevek.Add(nev[2]);
                    generaltNevek.Remove(string.Join(' ', nev));
                }
                catch
                {
                    MessageBox.Show("Nincs kiválasztott név!");
                }
            }
        }
    }
}
